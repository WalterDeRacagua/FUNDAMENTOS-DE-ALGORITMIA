//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

//Precondici�n: {0<=n < v.size()}
int pista_mas_larga(vector<int> v, int n) {//func pista_mas_larga(in vector<int> v, in int n) dev int l

    if (n==0)
    {
        return 0;
    }

    int s = 0;
    int r = 1;

    for (int i = 1; i < n; i++)// Funci�n de cota: n-i
    {
        //Invariante: 0< i <v.size() ^ 0<= s < v.size() ^ r = {max p,q: p<=i<q: v[i]<v[i-1]: q-p}
        if (v[i]>v[i-1])
        {
            s = i;
        }
        
        
        r = max(r, i-s+1);
        
    }

    //Coste: Lineal con respecto al n�mero de elementos.
    
    return r;
}
//Postcondici�n: r = {max p,q: p<=i<q: v[i]<v[i-1]: q-p}

void resuelveCaso() {
 
    int n; //Siendo n el n�mero de alturas.

    cin >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }


    int tramo_mas_largo = pista_mas_larga(v, n);

    cout << tramo_mas_largo << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}