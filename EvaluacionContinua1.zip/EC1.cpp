//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


//noMas(v,i,j,l): bool no_mas = {#x: i<=x < j: (v[x] % 2 !=0)<l}


//Precondici�n: 0<= n <= v.size() ^ l>=0 ^ 0<=k <=n.
int numero_segmentos(vector<int>v, int n, int k, int l) {//func numero_segmentos(in vector<int> v, in int n, in int k, in int l) dev int segmentos;

    int num_segmentos=1;
    int ini = 0;
    int num_impares = 0;
    
    //Funci�n de cota: n-i, con i inicialmente =k.
    //Coste: Es lineal en el n�mero de elementos 'n' del vector en el peor de los casos, puesto que se ejecuta
    //un bucle for de n iteraciones, y dentro del bucle se realizan asignaciones y comprobaciones de coste constante 
    //O(1), por tanto el coste total es O(n), lineal en el n�mero de elementos.

    for (int i = k; i < n; i++) {
        //Invariante del bucle:k<=i<n^ num_impares = {#i: 0<= i < v.size(): v[i]%2!=0} ^ num_segmentos = {#p,q: p<= i < q: noMas(v,p,q,l)}

        if (v[i] % 2 != 0) {
            num_impares++;
        }
        //Debemos de reducir el n�mero de impares del primer n�mero
        if (v[i - k] % 2 != 0) {
            num_impares--;
        }

        if (num_impares <= l) {
            num_segmentos++;
        }
    }

    return num_segmentos;
}
//Postcondici�n: num_segmentos = {#p,q: p<= i < q: (q - p = k)^noMas(v,p,q,l)}

void resuelveCaso() {
    
    int n, k, l; //Siendo n el n�mero de elementos, k el tamanyo del vector, l el numero maximo de impares.

    cin >> n >> k >> l;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    int segmentos = numero_segmentos(v, n, k, l);

    cout << segmentos << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}