//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53.

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

/*
EXPLICACI�N DEL PROBLEMA:

Se trata de un problema en el cual aplico el esquema algoritmico t�pico de la vuelta atr�s, en el cual
tenemos que conseguir inscribir a artistas para un concierto respetando una serie de vetos y consiguiendo
que las donaciones sean M�XIMAS.

DATOS OFRECIDOS EN EL ENUNCIADO:

El enunciado nos ofrece los siguientes datos:

    � int n: N�mero de artistas y de momentos.
    � vector<vector<int>> donaciones_estimadas: Donaci�n estimada del artista i si actua en el momento j.
    � vector<vector<int>> vetos_artistas: Nos dice si el artista i puede tocar despues del artista j. 1 si puede.0 en caso constrario.

�RBOL DE EXPLORACI�N:

El �rbol de exploraci�n que he planteado es un �rbol de profundidad n {0...n-1} y de anchura tambien n{0...n-1}. En cada nivel del �rbol
tomo la decisi�n de para el momento i que artista j puede actuar. Es decir, la profundidad es para cada momento, y la anchura es por el conjunto
de artistas. 

COSTE:

Como consecuencia del �rbol de exploraci�n, el coste T(n) de nuestro algoritmo es:

    T(n) E O(n^n)

RESTRICCIONES:

Las restricciones que se proponen en el problema son las siguientes:

    -EXPL�CITAS:
        
        � n es el n�mero de artistas que actuan
        � Se deben respetar los vetos de cada artista
        � Para estos vetos, tenemos una fila para cada artista y nos indica si el artista i puede actuar despu�s del artista j. 1 si puede, 0 si no puede.

    -IMPL�CITAS:
        
        � Es un problema de MAXIMIZACI�N, tenemos que conseguir la m�xima donaci�n posible.
        � SI no se puede por las restricciones, debemos mostrar NEGOCIA CON LOS ARTISTAS.

MARCADORES:

Los marcadores nos facilitan realizar una poda de factibilidad �ptima para evitar cargas en el coste de nuestro algoritmo a cambio
de ocupar m�s memoria. Los marcadores que he utilizado son los siguientes:

    � vector<bool> artistas_escogidos: Que artistas act�an ya de la rama que estamos explorando para no poder volver a escogerlos.
    � int donaciones_parciales: Nos dice el valor de las donaciones de la rama que estamos explorando.
    � int donaciones_maximas: Cuales son las donaciones en el caso mejor.
    � bool se_cumple : Variable que nos dice si podemos alcanzar una solci�n factible en nuestro problema.

Adem�s, utilizamos dos vectores para almacenar cual es la soluci�n mejor y la soluci�n de la rama que estamos explorando. En este caso, nos 
ayuda a conocer la factibilidad de nuestra solucion ya que tenemos que comprobar qu� artista act�a en el momento anterior para los vetos. Estos
vectores son:

    � vector<int> solucion_parcial: Nos dice para el momento i, que artista es el que act�a. Va almacenando soluci�n de la rama que estamos explorando.
    � vector<int> solucion_mejor: Nos dice para el momento i, que artista es el que act�a. Almacena la mejor soluci�n.

PODA_OPTIMALIDAD:

La poda de optimalidad nos ayuda a podar ramas que no nos llevan a la soluci�n �ptima. Podemos utilizar dos funciones:

    1.Que en el resto de momentos las donaciones sean como la maxima donaci�n. 

    estimacionDonacion= donaciones_parciales + (n-k-1)*max;

    Coste: O(n^2) antes del algoritmo.

    2.Para cada momento  tener calculado el maximo dinero estimado donado y los siguientes:

    estimacionDonacion = donaciones_parciales + sumaRapido[k]

    Coste: O(n^2) antes del algoritmo, pero es m�s realista que el caso anterior.


*/

void poda_optimalidad(const vector<vector<int>>& donaciones_estimadas, int n, vector<int> &sumaRapido) {

    vector<int> maximo(n);//Para cada momento cual es la mejor donaci�n...

    for (int i = 0; i < n; i++)
    {
        maximo[i] = donaciones_estimadas[0][i];
        for (int j = 0; j < n; j++)
        {
            maximo[i] = max(maximo[i], donaciones_estimadas[j][i]);
        }
    }

    sumaRapido[n - 1] = 0;

    for (int i = n-2; i >= 0; --i)
    {
        sumaRapido[i] = sumaRapido[i + 1] + maximo[i + 1];
    }
}


void orden_artistas_sin_poda(int n, const vector<vector<int>>& donaciones_estimadas, const vector<vector<int>>& vetos_artistas, vector<int>& solucion_parcial,vector<int> &solucion_mejor
, vector<bool> &artistas_escogidos,int &donaciones_parciales, int &donaciones_maximas,int &artistas_cumplen, bool & se_cumple, int k) {

    //Por cada nivel elegimos el artista.
    for (int artista = 0; artista < n; artista++)
    {
        if (!artistas_escogidos[artista]&& (k==0||vetos_artistas[artista][solucion_parcial[k-1]]!=0))//Si el artista no se ha escogido ni tiene vetado al artista anterior...
        {
            solucion_parcial[k] = artista; //El artista "artista" actua en el momento "k"

            /*MARCAJE*/
            artistas_escogidos[artista] = true; 
            donaciones_parciales += donaciones_estimadas[artista][k];
            
            if (k==n-1)
            {
                if (donaciones_parciales > donaciones_maximas)
                {
                    se_cumple = true;
                    donaciones_maximas = donaciones_parciales;
                    solucion_mejor = solucion_parcial;
                }
            }
            else
            {
                orden_artistas_sin_poda(n, donaciones_estimadas, vetos_artistas, solucion_parcial, solucion_mejor, artistas_escogidos, donaciones_parciales,
                    donaciones_maximas, artistas_cumplen, se_cumple, k + 1);
            }
            
            /*DESMARCAJE(al mismo nivel que el marcaje)*/
            artistas_escogidos[artista] = false;
            donaciones_parciales -= donaciones_estimadas[artista][k];
        }
    }
}void orden_artistas_con_poda(int n, const vector<vector<int>>& donaciones_estimadas, const vector<vector<int>>& vetos_artistas, vector<int>& solucion_parcial,vector<int> &solucion_mejor
, vector<bool> &artistas_escogidos,int &donaciones_parciales, int &donaciones_maximas,int &artistas_cumplen, bool & se_cumple, int k, vector<int>sumaRapido) {

    //Por cada nivel elegimos el artista.
    for (int artista = 0; artista < n; artista++)
    {
        if (!artistas_escogidos[artista]&& (k==0||(vetos_artistas[artista][solucion_parcial[k-1]]!=0)))//Si el artista no se ha escogido ni tiene vetado al artista anterior...
        {
            solucion_parcial[k] = artista; //El artista "artista" actua en el momento "k"

            /*MARCAJE*/
            artistas_escogidos[artista] = true; 
            donaciones_parciales += donaciones_estimadas[artista][k];
            
            if (k==n-1)
            {
                if (donaciones_parciales > donaciones_maximas)
                {
                    se_cumple = true;
                    donaciones_maximas = donaciones_parciales;
                    solucion_mejor = solucion_parcial;
                }
            }
            else
            {
                int estimacionDonacion = donaciones_parciales + sumaRapido[k];

                if (estimacionDonacion >= donaciones_maximas)
                {
                    orden_artistas_con_poda(n, donaciones_estimadas, vetos_artistas, solucion_parcial, solucion_mejor, artistas_escogidos, donaciones_parciales,
                        donaciones_maximas, artistas_cumplen, se_cumple, k + 1, sumaRapido);
                }
             
            }
            
            /*DESMARCAJE(al mismo nivel que el marcaje)*/
            artistas_escogidos[artista] = false;
            donaciones_parciales -= donaciones_estimadas[artista][k];
        }
    }
}

void resuelveCaso() {
    
    int n; //Siendo n el n�mero de artistas y de momentos.

    cin >> n;

    vector<vector<int>> donaciones_estimadas(n, vector<int>(n, 0));//Donaci�n estimada del artista i si actua en el momento j.
    vector<vector<int>> vetos_artistas(n, vector<int>(n, 0));//Nos dice si el artista i puede tocar despues del artista j. 1 si puede.


    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> donaciones_estimadas[i][j];
        }
    }


    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> vetos_artistas[i][j];
        }
    }

    vector<int> solucion_parcial(n, -1);//Nos dice para el momento i, que artista es el que act�a. Va almacenando soluci�n de la rama que estamos explorando.
    vector<int> solucion_mejor(n, -1); //Nos dice para el momento i, que artista es el que act�a. Almacena la mejor soluci�n.
    
    vector<bool> artistas_escogidos(n, false); //Que artistas act�an ya.
    int donaciones_parciales = 0; //Donaciones de la rama que estamos explorando
    int donaciones_maximas = 0;//Cuales son las donaciones en el caso mejor.
    int artistas_cumplen = 0; //Si est�n todos asignados
    bool se_cumple = false;//Si se cumplen todas  las restricciones en algun caso.

    vector<int> sumaRapido(n, -1);
    
    poda_optimalidad(donaciones_estimadas, n, sumaRapido);

 /*   orden_artistas_sin_poda(n, donaciones_estimadas, vetos_artistas, solucion_parcial, solucion_mejor, artistas_escogidos, donaciones_parciales,
        donaciones_maximas, artistas_cumplen, se_cumple, 0); */
    
    orden_artistas_con_poda(n, donaciones_estimadas, vetos_artistas, solucion_parcial, solucion_mejor, artistas_escogidos, donaciones_parciales,
        donaciones_maximas, artistas_cumplen, se_cumple, 0,sumaRapido);

    if (!se_cumple)
    {
        cout << "NEGOCIA CON LOS ARTISTAS\n";
    }
    else
    {
        cout << donaciones_maximas << endl;
    }

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}