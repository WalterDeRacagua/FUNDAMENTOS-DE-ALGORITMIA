#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm> // Necesario para std::sort
#include <climits> // Necesario para INT_MAX
using namespace std;

struct Proveedor {
    int stock;
    int precio;
    int index;
};

bool compararProveedores(const Proveedor& a, const Proveedor& b) {
    return a.precio < b.precio;
}

void comprar_mascarillas_con_poda(int n, int m, const vector<int>& mascarillas_facultad, const vector<Proveedor>& proveedores,
    vector<int>& solucion_parcial, vector<int>& solucion_mejor, vector<int>& facultad_satisfecha, int& precio_parcial, int& precio_mejor,
    bool& solucion, int k, int& facultades_cumplen) {

    if (precio_parcial >= precio_mejor) {
        // Poda porque ya hemos superado el mejor precio conocido
        return;
    }

    if (k == m) {
        if (facultades_cumplen == n && precio_parcial < precio_mejor) {
            solucion = true;
            precio_mejor = precio_parcial;
            solucion_mejor = solucion_parcial;
        }
        return;
    }

    // Opci�n 1: No suministrar a ninguna facultad
    comprar_mascarillas_con_poda(n, m, mascarillas_facultad, proveedores, solucion_parcial, solucion_mejor, facultad_satisfecha,
        precio_parcial, precio_mejor, solucion, k + 1, facultades_cumplen);

    for (int facultad = 0; facultad < n; facultad++) {
        if (facultad_satisfecha[facultad] < mascarillas_facultad[facultad]) {
            solucion_parcial[k] = facultad; // K suministra a facultad

            int diferencia = 0;
            int precio_incremento = 0;
            bool facultad_satisfecha_completamente = false;

            // MARCAJE
            if (facultad_satisfecha[facultad] + proveedores[k].stock >= mascarillas_facultad[facultad]) {
                diferencia = mascarillas_facultad[facultad] - facultad_satisfecha[facultad];
                facultad_satisfecha[facultad] += diferencia;
                precio_incremento = diferencia * proveedores[k].precio;
                precio_parcial += precio_incremento;
                facultades_cumplen++;
                facultad_satisfecha_completamente = true;
            }
            else {
                facultad_satisfecha[facultad] += proveedores[k].stock;
                precio_incremento = proveedores[k].stock * proveedores[k].precio;
                precio_parcial += precio_incremento;
            }

            // Llamada recursiva con poda
            if (precio_parcial < precio_mejor) {
                comprar_mascarillas_con_poda(n, m, mascarillas_facultad, proveedores, solucion_parcial, solucion_mejor, facultad_satisfecha,
                    precio_parcial, precio_mejor, solucion, k + 1, facultades_cumplen);
            }

            // DESMARCAJE
            if (facultad_satisfecha_completamente) {
                facultad_satisfecha[facultad] -= diferencia;
                precio_parcial -= precio_incremento;
                facultades_cumplen--;
            }
            else {
                facultad_satisfecha[facultad] -= proveedores[k].stock;
                precio_parcial -= precio_incremento;
            }
        }
    }
}

void resuelveCaso() {
    int n; // N�mero de Facultades
    int m; // N�mero de Suministradores

    cin >> n >> m;

    vector<int> mascarillas_facultad(n); // N�mero de mascarillas que necesita cada facultad 
    vector<Proveedor> proveedores(m); // Proveedores con su stock y precio

    for (int i = 0; i < n; i++) {
        cin >> mascarillas_facultad[i];
    }
    for (int i = 0; i < m; i++) {
        cin >> proveedores[i].stock;
    }
    for (int i = 0; i < m; i++) {
        cin >> proveedores[i].precio;
        proveedores[i].index = i; // Guardar el �ndice original
    }

    // Ordenar proveedores por precio ascendente
    sort(proveedores.begin(), proveedores.end(), compararProveedores);

    vector<int> solucion_parcial(m, -1); // Cada suministrador a qu� facultad suministra
    vector<int> solucion_mejor(m, -1); // Cada suministrador a qu� facultad suministra en el mejor caso
    vector<int> facultad_satisfecha(n, 0); // Cu�ntas mascarillas ha recibido cada facultad
    int precio_parcial = 0; // Precio de las mascarillas en la rama del �rbol de exploraci�n
    int precio_mejor = INT_MAX; // Mejor precio de las mascarillas
    bool solucion = false; // Indica si se ha encontrado una soluci�n
    int facultades_cumplen = 0;

    comprar_mascarillas_con_poda(n, m, mascarillas_facultad, proveedores, solucion_parcial, solucion_mejor, facultad_satisfecha,
        precio_parcial, precio_mejor, solucion, 0, facultades_cumplen);

    if (!solucion) {
        cout << "NO\n";
    }
    else {
        cout << precio_mejor << endl;
    }
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }

#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}
