// NOMBRE y APELLIDOS: Sergio S�nchez Carrasco

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

/*
EXPLICACI�N DEL PROBLEMA:

Se trata de un problema de vuelta atr�s en el cual tenemos que conseguir la
MINIMIZACI�N de los sueldos a pagar en distintos proyectos.

DATOS:

Los datos que nos proporciona el problema son los siguientes:

    �int m: n�mero de grupos
    �int n: n�mero de proyectos.
    �vector<int> personas_grupo: Cu�ntas personas conforman cada grupo.
    �vector<int> necesidades_minimas: Necesidades m�nimas de cada proyecto.
    �vector<int> necesidades_maximas: Necesidades m�ximas de cada proyecto.
    �vector<int> sueldos_proyecto: Para cada proyecto, sueldo de cada persona que pertenece a �l.


�RBOL DE EXPLORACI�N:

El �rbol de exploraci�n que he planteado para este problema consiste en un �rbol de profundidad m (ya que tenemos
desde el grupo 0 hasta el m-1), y de anchura n (ya que tenemos desde el proyecto 0 hasta el n-1). Por tanto, en cada nivel
del �rbol se tomar� la decisi�n de, para un grupo mi, a que proyecto ni pertenece.

COSTE:

Como consecuencia del �rbol de exploraci�n, el coste de nuestro �rbol pertenece (E) O(n^m).

RESTRICCIONES:

    -EXPL�CITAS:
        
        � Un equipo m solo debe pertenecer a un proyecto n
        � Un proyecto n puede estar formado por varios equipos i
        � El m�nimo de integrantes exigidos por un proyecto debe ser menor que el m�ximos exigido.
        � Se pueden superar las necesidades m�nimas, pero no las m�ximas.
        � Todos los equipos deben asignarse a un solo proyecto.

    -IMPL�CITAS:
        
        � Debemos minimizar el sueldo a pagar.
        � Se debe pagar a todas las personas del equipo.

MARCADORES:

Los marcadores que yo he utilizado para evitar aumentar el coste de nuestro algoritmo son los siguientes:

    � vector<int> personas_asignadas_proyectos: Para cada proyecto, el n�mero de personas asignadas
    � int sueldos_parcial: Sueldo acumulado para la rama que estamos explorando.
    � int sueldo_mejor: Mejor sueldo del caso base.
    � bool se_puede: booleano que nos dice si hemos conseguido alguna soluci�n factible.
    � int proyectos_cumplen: N�mero de proyectos que ya cumplen con las necesidades m�nimas.

Adem�s, para almacenar la soluci�n de la rama que estoy explorando y la mejor soluci�n de los casos base utilizo
dos vectores:

    �vector<int> solucion_parcial: Para cada grupo decimos el proyecto al que pertenece, rama que estamos explorando.
    �vector<int> solucion_mejor: Para cada grupo decimos el proyecto al que pertenece. Mejor soluci�n.

PODA DE OPTIMALIDAD:

Sirve para podar ramas del �rbol de exploraci�n de forma que evitamos soluciones que NO nos llevan a la soluci�n
�ptima. En mi caso, he utilizado el siguiente caso:

El resto de grupos por asignar nos costar�n como minimo el m�nimo de todos los proyectos por el n�mero de grupos.

Coste lineal en el n�mero de proyectos.


*/
void sueldos_equipos_sin_poda(const vector<int>& personas_grupo, const vector<int>& necesidades_minimas, const vector<int>& necesidades_maximas,
    const vector<int>& sueldos_proyecto, vector<int>& solucion_parcial, vector<int>& solucion_mejor, vector<int>& personas_asignadas_proyectos,
    int& sueldos_parcial, int& sueldo_mejor, int k, bool& se_puede, int n, int m, int& proyectos_cumplen,int mini) {

    for (int proyecto = 0; proyecto < n; proyecto++) {
        if (personas_asignadas_proyectos[proyecto] + personas_grupo[k] <= necesidades_maximas[proyecto]) {
            solucion_parcial[k] = proyecto; // Asignar grupo k al proyecto

            // MARCAJE
            if (personas_asignadas_proyectos[proyecto] < necesidades_minimas[proyecto] &&
                personas_asignadas_proyectos[proyecto] + personas_grupo[k] >= necesidades_minimas[proyecto]) {
                proyectos_cumplen++;
            }
            personas_asignadas_proyectos[proyecto] += personas_grupo[k];
            sueldos_parcial += sueldos_proyecto[proyecto] * personas_grupo[k];

            if (k == m - 1) {
                // Comprobar si todos los proyectos cumplen con necesidades m�nimas
                if (proyectos_cumplen == n) {
                    se_puede = true;
                    if (sueldos_parcial < sueldo_mejor) {
                        sueldo_mejor = sueldos_parcial;
                        solucion_mejor = solucion_parcial;
                    }
                }
            }
            else {

                int sueldo_estimado = sueldos_parcial + (m - k - 1) * mini;

                if (sueldo_estimado< sueldo_mejor)
                {
                    sueldos_equipos_sin_poda(personas_grupo, necesidades_minimas, necesidades_maximas, sueldos_proyecto, solucion_parcial,
                        solucion_mejor, personas_asignadas_proyectos, sueldos_parcial, sueldo_mejor, k + 1, se_puede, n, m, proyectos_cumplen,mini);
                }

                
            }

            // DESMARCAJE
            if (personas_asignadas_proyectos[proyecto] >= necesidades_minimas[proyecto] &&
                personas_asignadas_proyectos[proyecto] - personas_grupo[k] < necesidades_minimas[proyecto]) {
                proyectos_cumplen--;
            }
            personas_asignadas_proyectos[proyecto] -= personas_grupo[k];
            sueldos_parcial -= sueldos_proyecto[proyecto] * personas_grupo[k];
        }
    }
}

void resuelveCaso() {
    int m, n; // Siendo m el n�mero de grupos, y n el n�mero de proyectos.
    int mini = 999999;

    cin >> m >> n;

    vector<int> personas_grupo(m, 0); // Cu�ntas personas conforman cada grupo.
    vector<int> necesidades_minimas(n, 0); // Necesidades m�nimas de cada proyecto.
    vector<int> necesidades_maximas(n, 0); // Necesidades m�ximas de cada proyecto.
    vector<int> sueldos_proyecto(n, 0); // Para cada proyecto, sueldo de cada persona que pertenece a �l.

    for (int i = 0; i < m; i++) {
        cin >> personas_grupo[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> necesidades_minimas[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> necesidades_maximas[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> sueldos_proyecto[i];
        mini = min(mini, sueldos_proyecto[i]);
    }

    vector<int> solucion_parcial(m, -1); // Para cada grupo decimos el proyecto al que pertenece
    vector<int> solucion_mejor(m, -1); // Para cada grupo decimos el proyecto al que pertenece. Mejor soluci�n.
    vector<int> personas_asignadas_proyectos(n, 0); // Para cada proyecto, el n�mero de personas asignadas
    int sueldos_parcial = 0;
    int sueldo_mejor = 1000000;
    bool se_puede = false;
    int proyectos_cumplen = 0;

    sueldos_equipos_sin_poda(personas_grupo, necesidades_minimas, necesidades_maximas, sueldos_proyecto, solucion_parcial,
        solucion_mejor, personas_asignadas_proyectos, sueldos_parcial, sueldo_mejor, 0, se_puede, n, m, proyectos_cumplen, mini);

    if (!se_puede) {
        cout << "NO\n";
    }
    else {
        cout << sueldo_mejor << endl;
    }
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (unsigned int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }

#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}
