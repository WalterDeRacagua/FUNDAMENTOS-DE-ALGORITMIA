//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


/*
EXPLICACI�N DEL PROBLEMA:

Se trata de un problema de vuelta atr�s donde tenemos que conseguir la mejor soluci�n. En este caso la mejor soluci�n
consistir� en la soluci�n para la cual la calidad es m�xima, luego es un problema de maximizaci�n.


DATOS DEL PROBLEMA:

    � int n: �s el n�mero de carros quitanieves.
    � int m: Es el n�mero de caminos a limpiar respectivamente.
    � vector<int> anchuras_carros(n): Vector de anchuras de los n carros quitanieves haya.
    � vector<int> anchuras_caminos(m): Vector de anchuras de los m caminos a limpiar que haya.
    � vector<vector<int>> calidades(n, vector<int>(m, 0)): Matriz con la calidad con la que el carro i limpia el camino j


�RBOL DE EXPLORACI�N:

El �rbol de exploraci�n que he desarrollado para este problema es un �rbol de profundidad n siendo n el n�mero de carros quitanieves;
y de anchura m siendo m el n�mero de caminos a limpiar. Por tanto en cada nivel del �rbol tomaremos la decisi�n de, para cada quitanieves,
cual va a ser el camino que limpie.

COSTE COMO CONSECUENCIA DEL �RBOL EXPLORACI�N:

El coste de nuestro algoritmo en consecuencia del �rbol de exploraci�n pertence al siguiente orden:
    
    Coste E O(m^n).


RESTRICCIONES:

    -EXPL�CITAS:

        � El n�mero de caminos 'm' es mayor que el n�mero de m�quinas quitanieves 'n'. 0<=n< m <=50.
        � Cada carro y cada camino tienen su anchura. 0 < ai <=1000.
        � Un carro de anchura 'a' solo podr� limpiar caminos cuya anchura sea >= que 'a'
        � Cada carro limpia a lo sumo un camino
        � Cada camino es limpiado a lo sumo por un camino, pudiendo haber caminos sin limpiar.
        � Las calidades 'cij' 0< cij<= 1000.

    -IMPL�CITAS:
        
        � Problema de maximizaci�n.
        


MARCADORES:
Los marcadores sirven para reducir el coste asintotico de nuestro problema, pero debemos a�adir nuevas variables.
Los marcadores que he utilizado son:

    � vector<bool> caminos_limpiados(m, 0): Vector que almacena para cada camino si ha sido limpiado ya o no. 
    � int calidad_parcial=0
    � calidad_mejor=-1

Adem�s, utilizo dos vectores auxiliares para almacenar la soluci�n parcial y la soluci�n mejor.

PODA OPTIMALIDAD:

La poda de optimalidad la utilizamos para evitar explorar ramas que NO nos conducen a la soluci�n �ptima del problema.
Voy a definir distintas opciones ordenadas de menos a m�s realista:

OPCION 1:

    Que el resto se limpien con la calidad maxima que es 1000. Es muy poco realista

    calidadEstimada = calidad_parcial + (n-k-1)*1000;

    Coste: O(1), pero es poco realista

OPCI�N 2:

    Que el resto se limpien con la calidad m�xima de toda la matriz.

    calidadEstimada = calidad_parcial + (n-k-1)*maxCalidad.

    Coste: O(n^2), pero aun tenemos opciones m�s realistas.

OPCI�N 3:

    Que el resto se limpien con la calidadM�xima a partir de los siguientes
    
    calidadEstima = calidad_parcial + (n-k-1)*max[k]

    Coste: O(n^2) 


OPCI�N 4:

    Que el resto se limpien con la suma de los maximos restantes.

    calidadEstimada = calidad_parcial + sumaRapido[k].

    Coste: O(n^2)
*/

void poda_optimalidad_opcion4(const vector<vector<int>>& calidades, int n, int m, vector<int> & sumaRapido) {

    vector<int> maximos(n);

    for (int i = 0; i < n; i++)
    {
        maximos[i] = calidades[i][0];
        for (int j = 1; j < m; j++)
        {
            maximos[i] = max(maximos[i], calidades[i][j]);
        }
    }

    sumaRapido[n - 1] = 0;

    for (int i = n-2; i >= 0; --i)
    {
        sumaRapido[i] = maximos[i + 1] + sumaRapido[i + 1];
    }


}

void quitanieves_caminos_sin_poda(const vector<vector<int>>  & calidades, const vector<int> &anchuras_carros, const vector<int> & anchuras_caminos,int n, int m,
vector<int> &solucion_parcial, vector<int> &solucion_mejor, vector<bool> &caminos_limpiados, int &calidad_parcial, int &calidad_mejor, int k) {

    for (int camino = 0; camino < m; camino++)
    {
        //Para que el camino sea valido tenemos que comprobar si esta ya asignadoy si la anchura del carroquitanieves
        if (!caminos_limpiados[camino] && anchuras_carros[k] <= anchuras_caminos[camino])
        {
            solucion_parcial[k] = camino;//El carro k limpia el camino 'camino'
            /*MARCAJE*/
            caminos_limpiados[camino] = true;
            calidad_parcial += calidades[k][camino];  

            
            if (k ==n-1)//Si hemos llegado al �ltimo carro quitanieves...
            {
                //Comprobamos si la soluci�n parcial almacenada es mejor que la solucion mejor almacenada...
                if (calidad_parcial > calidad_mejor)//Implicaria que este camino nos lleva a una mejor calidad.
                {
                    solucion_mejor = solucion_parcial;
                    calidad_mejor = calidad_parcial;
                }
            }
            else
            {
                //Pasamos al siguiente carro quitanieves.
                quitanieves_caminos_sin_poda(calidades, anchuras_carros, anchuras_caminos, n, m, solucion_parcial,
                    solucion_mejor, caminos_limpiados, calidad_parcial, calidad_mejor, k + 1);
            }    

            /*DESMARCAJE (Al mismo nivel, importante siempre.)*/
            caminos_limpiados[camino] = false;
            calidad_parcial -= calidades[k][camino]; 
        }
    }
    if (k == n-1)
    {
        if (calidad_parcial > calidad_mejor)//Implicaria que este camino nos lleva a una mejor calidad.
        {
            solucion_mejor = solucion_parcial;
            calidad_mejor = calidad_parcial;
        }
    }
    else
    {
        //Pasamos al siguiente carro quitanieves.
        quitanieves_caminos_sin_poda(calidades, anchuras_carros, anchuras_caminos, n, m, solucion_parcial,
            solucion_mejor, caminos_limpiados, calidad_parcial, calidad_mejor, k + 1);
    }

}

void quitanieves_caminos_con_poda(const vector<vector<int>>  & calidades, const vector<int> &anchuras_carros, const vector<int> & anchuras_caminos,int n, int m,
vector<int> &solucion_parcial, vector<int> &solucion_mejor, vector<bool> &caminos_limpiados, int &calidad_parcial, int &calidad_mejor, int k, vector<int> sumaRapido) {

    for (int camino = 0; camino < m; camino++)
    {
        //Para que el camino sea valido tenemos que comprobar si esta ya asignadoy si la anchura del carroquitanieves
        if (!caminos_limpiados[camino] && anchuras_carros[k] <= anchuras_caminos[camino])
        {
            solucion_parcial[k] = camino;//El carro k limpia el camino 'camino'
            /*MARCAJE*/
            caminos_limpiados[camino] = true;
            calidad_parcial += calidades[k][camino];  

            
            if (k ==n-1)//Si hemos llegado al �ltimo carro quitanieves...
            {
                //Comprobamos si la soluci�n parcial almacenada es mejor que la solucion mejor almacenada...
                if (calidad_parcial > calidad_mejor)//Implicaria que este camino nos lleva a una mejor calidad.
                {
                    solucion_mejor = solucion_parcial;
                    calidad_mejor = calidad_parcial;
                }
            }
            else
            {
                //Pasamos al siguiente carro quitanieves.

                int calidadEstimada = calidad_parcial + sumaRapido[k];

                if (calidadEstimada > calidad_mejor)
                {
                    quitanieves_caminos_con_poda(calidades, anchuras_carros, anchuras_caminos, n, m, solucion_parcial,
                        solucion_mejor, caminos_limpiados, calidad_parcial, calidad_mejor, k + 1, sumaRapido);
                }               
                
            }    

            /*DESMARCAJE (Al mismo nivel, importante siempre.)*/
            caminos_limpiados[camino] = false;
            calidad_parcial -= calidades[k][camino]; 
        }
    }
    if (k == n-1)
    {
        if (calidad_parcial > calidad_mejor)//Implicaria que este camino nos lleva a una mejor calidad.
        {
            solucion_mejor = solucion_parcial;
            calidad_mejor = calidad_parcial;
        }
    }
    else
    {
        //Pasamos al siguiente carro quitanieves.
        int calidadEstimada = calidad_parcial + sumaRapido[k];

        if (calidadEstimada > calidad_mejor)
        {
            quitanieves_caminos_con_poda(calidades, anchuras_carros, anchuras_caminos, n, m, solucion_parcial,
                solucion_mejor, caminos_limpiados, calidad_parcial, calidad_mejor, k + 1, sumaRapido);
        }
    }

}

void resuelveCaso() {

    int n, m; //Son el n�mero de carros quitanieves, y el n�mero de caminos a limpiar respectivamente.

    cin >> n >> m;

    vector<int> anchuras_carros(n);//Tantas anchuras como carros quitanieves haya.
    vector<int> anchuras_caminos(m);//Tantas anchuras como caminos
    vector<vector<int>> calidades(n, vector<int>(m));//Matriz con la calidad con la que el carro i limpia el camino j. Inicializadas de momento a 0.

    for (int i = 0; i < n; i++)
    {
        cin >> anchuras_carros[i];
    }

    for (int i = 0; i < m; i++)
    {
        cin >> anchuras_caminos[i];
    }

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> calidades[i][j];
        }
    }

    vector<int> solucion_parcial(n, -1);//vector en el que almaceno para cada carro quitanieves, el camino que limpia.
    vector<int> solucion_mejor(n, -1);//Vector que almacena la mejor soluci�n.
    vector<bool> caminos_limpiados(m, 0);//Vector que almacena para cada camino si ha sido limpiado ya o no. (marcador)
    int calidad_parcial=0, calidad_mejor=-1; //Enteros que almacenan la calidad acumulada de la rama que estamos explorando y que almacena la calidad mejor respectivamente.
    
    vector<int> sumaRapido(n, 0);

    poda_optimalidad_opcion4(calidades, n, m, sumaRapido);

    quitanieves_caminos_con_poda(calidades, anchuras_carros, anchuras_caminos, n, m, solucion_parcial,
        solucion_mejor, caminos_limpiados, calidad_parcial, calidad_mejor, 0,sumaRapido);

    cout << calidad_mejor << endl;

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}