//NOMBRE y APELLIDOS:Sergio S�nchez Carrasco E53.

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


/*
EXPLICACI�N DEL EJERCICIO:

Se trata de un ejercicio de recursi�n en el cual aplicamos el esquema de vuelta atr�s para resolverlo.
Adem�s, dentro de los problemas de vuelta atr�s, este es un problema de minimizaci�n.

DATOS DEL EJERCICIO:
    
    � int n: Es el n�mero de productos
    � int m: Es el n�mero de supermercados.
    � b vector<int> productos_comprados_por_supermercado: Es el precio del producto j en el supermercado i.

�RBOL DE EXPLORACI�N:

El �rbol de exploraci�n que he planteado yo es un �rbol de profundidad n-1 y de anchura m-1. Esto quiere decir que,
para cada producto, decido en qu� supermercado comprarlo. 

COSTE:

Como consecuencia del �rbol de exploraci�n, el coste de nuestro algorimto pertenece al siguiente orden: O(m^n).

RESTRICCIONES:


    -EXPL�CITAS

        � 0<= n <=3*m donde n es el n�mero de productos y m el n�mero de supermercados.
        � El n�mero de supermercados m <= 20.
        � No podemos comprar m�s de 3 productos en el mismo supermercado.
        � Debe comprar TODOS los productos, solo 1 de cada tipo.


    -IMPL�CITAS:
        
        � Coste debe ser m�nimo.

MARCADORES:

Los utilizamos para evitar mayores costes para el algoritmo por ejemplo a la hora de hacer la poda
de factibilidad. Mis marcadores son los siguientes:

    � vector<int> productos_comprados_por_supermercado: Para cada supermercado sabemos si ya ha escogido el limite de productos (3).
    � int precio_parcial: El precio hasta el momento de la rama que estamos explorando del �rbol
    � int precio_mejor: El mejor precio de la compra.

PODA DE OPTIMALIDAD:

Sirve para evitar explorar ramas que NO nos llevan a la soluci�n �PTIMA. Mi poda de factibilidad consiste en lo siguiente:


Debo calcular antes de la vuelta atr�s cual es el coste menor de comprar el resto de productos que nos quedan por comprar para
cada producto que estamos explorando:

    coste_estimado = precio_parcial + sumaRapido[k]

    Coste: O(n*m);


*/
void poda_optimalidad(const vector<vector<int>>& precios, int m, int n, vector<int>& sumaRapido) {

    vector<int> minimo(n);

    for (int i = 0; i < n; i++)
    {
        minimo[i] = precios[0][i];
        for (int j = 1; j < m; j++)
        {
            minimo[i] = min(minimo[i], precios[j][i]);
        }
    }

    sumaRapido[n - 1] = 0;

    for (int i = n-2; i >= 0; --i)
    {
        sumaRapido[i] = minimo[i + 1] + sumaRapido[i + 1];
    }

}

void productos_supermercados_sin_poda(const vector<vector<int>> & precios,int n, int m, vector<int> solucion_parcial,
vector<int> & solucion_mejor,vector<int> &productos_comprados_por_supermercado, int &precio_parcial ,int &precio_mejor, int k) {

    for (int supermercado = 0; supermercado < m; supermercado++)
    {
        if (productos_comprados_por_supermercado[supermercado]<3)
        {
            solucion_parcial[k] = supermercado;

            /*MARCAJE*/
            productos_comprados_por_supermercado[supermercado]++;
            precio_parcial += precios[supermercado][k];
            
            if (k == n-1)//Ultimo producto
            {
                if (precio_parcial< precio_mejor)
                {
                    precio_mejor = precio_parcial;
                    solucion_parcial = solucion_mejor;
                }
            }
            else
            {
                productos_supermercados_sin_poda(precios, n, m, solucion_parcial,
                    solucion_mejor, productos_comprados_por_supermercado, precio_parcial, precio_mejor, k + 1);
            }
            
            
            /*DESMARCAJE (Siempre al mismo nivel)*/
            productos_comprados_por_supermercado[supermercado]--;
            precio_parcial -= precios[supermercado][k];
        }
    }
}
void productos_supermercados_con_poda(const vector<vector<int>> & precios,int n, int m, vector<int> solucion_parcial,
vector<int> & solucion_mejor,vector<int> &productos_comprados_por_supermercado, int &precio_parcial ,int &precio_mejor, int k, vector<int> sumaRapido) {

    for (int supermercado = 0; supermercado < m; supermercado++)
    {
        if (productos_comprados_por_supermercado[supermercado]<3)
        {
            solucion_parcial[k] = supermercado;

            /*MARCAJE*/
            productos_comprados_por_supermercado[supermercado]++;
            precio_parcial += precios[supermercado][k];
            
            if (k == n-1)//Ultimo producto
            {
                if (precio_parcial< precio_mejor)
                {
                    precio_mejor = precio_parcial;
                    solucion_parcial = solucion_mejor;
                }
            }
            else
            {
                int precio_estimado = precio_parcial + sumaRapido[k];
                if (precio_estimado< precio_mejor)
                {
                    productos_supermercados_con_poda(precios, n, m, solucion_parcial,
                        solucion_mejor, productos_comprados_por_supermercado, precio_parcial, precio_mejor, k + 1,sumaRapido);
                }
                
            }
            
            
            /*DESMARCAJE (Siempre al mismo nivel)*/
            productos_comprados_por_supermercado[supermercado]--;
            precio_parcial -= precios[supermercado][k];
        }
    }
}

void resuelveCaso() {
    
    int n, m; //Siendo n el n�mero de productos y m el n�mero de supermercados.

    cin >> m >> n;

    vector<vector<int>> precios(m, vector<int>(n));//m filas y n columnas, para el supermercado i, muestra el precio del producto j

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> precios[i][j];
        }
    }

    vector<int> solucion_parcial(n);
    vector<int> solucion_mejor(n);
    vector<int> productos_comprados_por_supermercado(m, 0);//Para cada supermercado sabemos si ya ha escogido el limite de productos.

    int precio_parcial=0; //El precio hasta el momento de la rama que estamos explorando del �rbol
    int precio_mejor= 1000000;//El precio m�s barato

    vector<int> sumaRapido(n);

    poda_optimalidad(precios, m, n, sumaRapido);

    productos_supermercados_sin_poda(precios, n, m, solucion_parcial,
        solucion_mejor, productos_comprados_por_supermercado, precio_parcial, precio_mejor, 0);
  /*  productos_supermercados_con_poda(precios, n, m, solucion_parcial,
        solucion_mejor, productos_comprados_por_supermercado, precio_parcial, precio_mejor, 0, sumaRapido);*/

    cout << precio_mejor << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}