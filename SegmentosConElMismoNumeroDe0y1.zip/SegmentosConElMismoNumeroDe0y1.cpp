//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


//a) Para hacer esto voy a definir 2 predicados auxiliares:
// ceros(v,p,q) ={# i: 0<=i< n: v[i]=0} ^ unos(v,p,q)= {# i: 0<=i< n: v[i]=1}
// cerosUnos= {# p,q: 0<=p<q<n: ceros(v,p,q)=unos(v,p,q) ^ q-p =l}

//Precondici�n: {0<=n< v.size()^ l>0}
int segmentos_unos_ceros( vector<int> v, int n, int l) {//func segmentos_unos_ceros(in vector<int> v, in int n, in int l) dev int segmentos

    int segmentos = 0;
    int  ceros = 0;
    int unos = 0;
    int tamanyo_segmento = 0;

    //Funci�n de cota = n-i
    //Coste: El coste del algoritmo es lineal con respecto al n�mero de posiciones del vector, puesto que recorremos
    //el vector una sola vez y dentro del mismo hacemos operaciones de coste constante. Por tanto O(n).
    for (int i = 0; i < n; i++)
    {
        //Invariante: 0<=i<v.size() ^ 0<=tamanyo_segmento<=l ^ ceros(v,p,q) ={# i: 0<=i< n: v[i]=0} ^ unos(v,p,q)= {# i: 0<=i< n: v[i]=1} ^ segmentos = {# p,q: 0<=p<q<n: ceros(v,p,q)=unos(v,p,q) ^ q-p =l}
        tamanyo_segmento++;
        if (v[i]==0)
        {
            ceros++;
        }
        else if (v[i]==1)
        {
            unos++;
        }
        if (tamanyo_segmento == l)
        {
            if (ceros == unos)
            {
                segmentos++;
            }
            if (v[i-l+1] ==0)
            {
                ceros--;
            }
            else if (v[i-l+1]== 1)
            {
                unos--;
            }
            tamanyo_segmento--;
        }
    }

    return segmentos;
}
//Postcondici�n: segmentos = {# p,q: 0<=p<q<n: ceros(v,p,q)=unos(v,p,q) ^ q-p =l}



void resuelveCaso() {
  
    int l, n; //Donde n es el tama�o de los segmentos, y n es el n�mero de elementos del vector.

    cin >> l >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    int num_segmentos=segmentos_unos_ceros(v, n, l);

    cout << num_segmentos << endl;

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}