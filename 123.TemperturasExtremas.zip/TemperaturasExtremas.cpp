//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 


#include <vector>
#include <iostream>
#include <fstream>
#include <utility>
using namespace std;

//PRE: {0<n<=datos.size()}
pair<int, int> picos_valles(const vector<int> & datos, int n) {

    int picos=0, valles=0;

    for (int i = 1; i < n-1; i++)//Funci�n de cota = N-1-i.
    {
        //INVARIANTE: 0<i< n-1 ^ picos = {#i: 0<i<n-1 : datos[i-1]<datos[i]> datos[i+1]} ^ valles = {#i: 0<i<n-1 : datos[i-1]>datos[i]< datos[i+1]}
        if (datos[i-1]< datos[i] && datos[i+1]< datos[i])
        {
            picos++;
        }
        else if (datos[i-1]> datos[i]&& datos[i+1]> datos[i])
        {
            valles++;
        }
    }


    return { picos,valles };
}

//POST:picos = {#i: 0<i<n-1 : datos[i-1]<datos[i]> datos[i+1]} ^ valles = {#i: 0<i<n-1 : datos[i-1]>datos[i]< datos[i+1]}
// El coste de este bucle es del orden de n siendo n el n�mero de elementos del bucle, ya que dentro del bucle �nicamente hacemos comprobaciones y asignaciones 
// de coste constante. Luego coste E O(n).
//  

void resuelveCaso() {
  
    int n;
   

    cin >> n;

    vector<int> datos(n);

    for (int i = 0; i < n; i++)
    {
        cin >> datos[i];
    }

    auto [picos, valles] = picos_valles(datos, n);

    cout << picos << " " << valles << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}