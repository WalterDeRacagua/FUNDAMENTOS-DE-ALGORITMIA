//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco

#include <vector>
#include <iostream>
#include <fstream>
#include <utility>
using namespace std;

pair<long long int, long long int> suma_numero_valores(vector<long long  int> v, long long  int n) {

    pair<int, int> minimo_veces_repetido{v[0],1};
    long long int suma = v[0];
    long long int numValores = 1;
    long long int minimo = v[0];

    for (int i = 1; i < n; i++)
    {
        if (v[i]< minimo)
        {
            minimo = v[i];
            minimo_veces_repetido = { v[i], 1 };
        }
        else if (v[i]== minimo)
        {
            minimo_veces_repetido.second++;
        }
    
        suma += v[i];
        numValores++;
    }

    suma -= minimo_veces_repetido.first * minimo_veces_repetido.second;
    numValores -= minimo_veces_repetido.second;


    return { suma,numValores };
}

void resuelveCaso() {
    
    long long int n;//n es el tama�o del vector.

    cin >> n;

    vector<long long  int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    auto [suma, num_valores] = suma_numero_valores(v, n);

    cout << suma << " " << num_valores << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}