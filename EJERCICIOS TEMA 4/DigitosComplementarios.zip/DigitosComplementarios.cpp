//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <iostream>
#include <fstream>
using namespace std;

/*
Se trata de una funci�n recursiva no final. Su recurrencia la voy a definir sobre el n�mero de d�gitos
del n�mero, a los cuales voy a denominar n.

        {k0             si n<10.
    T(n)=
        {T(n-1) + k1    si n>10

Por lo tanto, podemos definir el coste utilizando el teorema de la resta. Como consecuencia de que tenemos una llamada
recursiva a=1 y el coste por tanto ser� lineal con respecto al n�mero de d�gitos. O(n)

*/

void numero_complementario(int numero, int &
    complementario) {

    if (numero < 10)
    {
        complementario = 9 - numero;
    }
    else
    {
        int ultimoDigito = numero % 10;
        int comp= 9-ultimoDigito;


        numero_complementario(numero/10,complementario);

        complementario = complementario * 10 + comp;

    }
}



/*
Se trata de una funci�n recursiva no final. Su recurrencia la voy a definir sobre el n�mero de d�gitos
del n�mero, a los cuales voy a denominar n.

        {k0             si n<10.
    T(n)=
        {T(n-1) + k1    si n>10

Por lo tanto, podemos definir el coste utilizando el teorema de la resta. Como consecuencia de que tenemos una llamada
recursiva a=1 y el coste por tanto ser� lineal con respecto al n�mero de d�gitos. O(n).

*/
void numero_inverso(int numero, int& inverso, int& p) {

    if (numero <10)
    {
        inverso = 9 - numero;
        p = 10;
    }
    else
    {
        int ultimoDigito = numero % 10;
        int comp = 9 - ultimoDigito;

        numero_inverso(numero / 10, inverso, p);

        inverso = comp * p + inverso;
        p = p * 10;
    }

}


void resuelveCaso() {

    int numero, complementario, potencia, inverso;

    cin >> numero;

    numero_complementario(numero, complementario);

    cout << complementario << " ";

    numero_inverso(numero, inverso, potencia);

    cout << inverso << endl;


}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}