//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53. 

#include <iostream>
#include <fstream>
using namespace std;

/*
RECURRENCIA Y COSTE

Se trata de un algoritmo recursivo lineal no final (puesto que lo �ltimo que hacemos NO es la funci�n recursiva).
Voy a definir la recurrencia y el coste sobre el n�mero de d�gitos "n" que tienen los n�meros de los casos de prueba.
Como en el caso base hacemos asignaciones de coste constante, y en el caso recursivo hacemos asignaciones tambi�n de 
coste constante y una �nica llamada recursiva de tama�o n-1, tenemos que la recurrencia es de la siguiente forma:

        {k0                 si n=1;
    T(n)
        {1 * T(n-1) + k1    si n>1;

Aplicando el teorema de la sustracci�n, como a = 1, el coste ser� del orden de O(n^(k+1)). Como k=0, entonces ser� lineal
con respecto al n�mero de d�gitos del n�mero.
*/


void codigo_a_introducir(int numero, int menor, int &mayor, bool esPar, int &resultado) {

    if (numero<10)
    {
        resultado = numero * 3 + menor;
        mayor = numero;
    }
    else
    {
        int ultimoDigito = numero % 10;

        codigo_a_introducir(numero/10, min(menor, ultimoDigito) , mayor, !esPar, resultado);

       

        if (esPar)
        {
            resultado += ultimoDigito * 2 + mayor;
        }
        else
        {
            resultado += ultimoDigito * 3 + menor;
        }
        mayor = max(mayor, ultimoDigito);

    }
}


void resuelveCaso() {

    int numero; //Numero sobre el cual hacemos el problema
    int mayor_izquierda;
    int resultado;

    cin >> numero;

    codigo_a_introducir(numero,9, mayor_izquierda, true, resultado);

    cout << resultado << endl;



}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}