// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <iostream>
#include <fstream>
using namespace std;


void es_sum_divisible(int numero,int &suma, int &digitos, bool &esDvisible) {

    if (numero <10)
    {
        suma = numero;
        digitos = 1;
        esDvisible = true;
    }
    else
    {
        int ultimoDigito = numero % 10;
        es_sum_divisible(numero / 10, suma, digitos, esDvisible);

        suma += ultimoDigito;

        digitos++;

        if (suma % digitos!=0)
        {
            esDvisible = false;
        }

    }



}


bool resuelveCaso() {

    int numero, suma,digitos;
    bool esDivisible;

    cin >> numero;

    if (numero ==0)
        return false;

    es_sum_divisible(numero, suma, digitos, esDivisible);

    if (esDivisible)
    {
        cout << "SI\n";
    }
    else
    {
        cout << "NO\n";
    }



    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}