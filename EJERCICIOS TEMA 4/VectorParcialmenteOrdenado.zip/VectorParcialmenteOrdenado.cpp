
// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;


/*
AN�LISIS DE LA RECURRENCIA Y EL COSTE DEL ALGORITMO.

Se trata de un algoritmo de recursi�n m�ltiple, ya que en cada llamada recursiva se acceden
a otras dos llamadas recursivas de tama�o la mitad. El coste y la recurrencia lo voy a definir 
sobre el tama�o del vector v.size() al cual voy a denominar como "N". De forma que la recurrencia 
en N es de la  siguiente forma:

        {k0             si N=1;
    T(N)
        {2T(n/2)+ k1    si N >1;

Como vemos cuando N>1 tenemos dos llamadas recursivas de coste la mitad + algo de coste constante. Por tanto,
como a = 2, b = 2 y k=0, aplicando el teorema de la divisi�n, a> b^k ya que 2 >1 por tanto el coste est� en
el O(n^(log(b)a)) como a y b son iguales log =1 y por tanto el coste es lineal con respecto a N, T(N) E O(N)


*/
void vector_parcialmente_ordenado(const vector<int>& v, int c, int f, int &maximo, int &minimo, bool &esta_ordenado) {

    if (c== f)
    {
        //Caso base
        esta_ordenado = true;
        maximo = v[c];
        minimo = v[c];
    }
    else 
    {
        int m = (c + f) / 2;
        bool esta_ordenado_izquierda, esta_ordenado_derecha;
        int maximo_derecha, minimo_derecha,maximo_izquierda, minimo_izquierda;

        vector_parcialmente_ordenado(v,c,m, maximo_izquierda,  minimo_izquierda, esta_ordenado_izquierda);
        vector_parcialmente_ordenado(v,m+1,f, maximo_derecha, minimo_derecha, esta_ordenado_derecha);

        esta_ordenado = esta_ordenado_izquierda && esta_ordenado_derecha && maximo_derecha >= maximo_izquierda&&minimo_izquierda<=minimo_derecha;
        maximo = max(maximo_izquierda, maximo_derecha);
        minimo = min(minimo_izquierda, minimo_derecha);


    }



}


bool resuelveCaso() {

    int n;//Siendo n los numeros que vamos leyendo del vector
    int maximo, minimo;
    bool esta_ordenado;

    cin >> n;

    if (n==0)
        return false;

    vector<int> v;

    while (n!=0)//Lineal con respecto al n�mero de n�meros del vector.
    {
        v.push_back(n);//Operacion de la stl de vector con conste constante (visto en ED)
        cin >> n;
    }

    vector_parcialmente_ordenado(v, 0, v.size() - 1, maximo, minimo, esta_ordenado);

    if (esta_ordenado)
    {
        cout << "SI\n";
    }
    else
    {
        cout << "NO\n";
    }


    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}