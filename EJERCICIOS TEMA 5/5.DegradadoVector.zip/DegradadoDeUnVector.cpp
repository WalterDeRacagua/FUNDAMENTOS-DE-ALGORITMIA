
//NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53.

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/*
COSTE Y RECURRENCIA DE MI ALGORITMO:

Se trata de un algoritmo de divide y vencer�s que trata de calcular si una imagen
es degradada o esta bien degradada. El resultado lo devuelvo a trav�s del parametro es_degradada.
En cuanto al coste y a la recurrencia de mi algoritmo lo voy a definir sobre N = f-c. 

Recurrencia:

        {k0             si N =1;
    T(N)
        {2T(n/2) +k1    si N>1;

Por tanto, aplicando el teorema de la divisi�n, siendo a = 2 (2 llamadas recursivas) b= 2 (se reduce
a la mitad) y k=0 tenemos que a > b^k 2> 2^0 luego T(N) E O(N^(logb(a))); como b = a logb(a)=1.
Por tanto T(N) E O(N^1), lineal en en N siendo N = f-c

*/
void es_fila_degradada(vector<int> const& v, int c, int f, int& suma, bool& es_degradada) {

    //No estoy haciendo una busqueda.
    if (f == c)
    {
        suma = v[c];
        es_degradada = true;
    }
    else
    {
        int m = (c + f) / 2;

        int sumaIzquierda, sumaDerecha;
        bool es_degradada_izquierda, es_degradada_derecha;

        es_fila_degradada(v, c, m, sumaIzquierda, es_degradada_izquierda);
        es_fila_degradada(v, m+1, f, sumaDerecha, es_degradada_derecha);

        es_degradada = es_degradada_derecha && es_degradada_izquierda && sumaIzquierda < sumaDerecha;

        suma = sumaIzquierda + sumaDerecha;
    }
}


bool resuelveCaso() {

    int n, m; //Numero de filas y de columnas respectivamente.

    cin >> n >> m;

    if (cin.eof())
        return false;

    vector<vector<int>> v(n, vector<int>(m, 0));//Solo voy a recorrer las filas una por una
    int suma;
    bool es_degradada, d = true;


    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> v[i][j];
        }
    }

    int z = 0;

    while (z < n && d)
    {

        es_fila_degradada(v[z], 0, v[z].size() - 1, suma, es_degradada);
        d = es_degradada;
        z++;
    }



    if (d)
    {
        cout << "SI\n";
    }
    else
    {
        cout << "NO\n";
    }

    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}