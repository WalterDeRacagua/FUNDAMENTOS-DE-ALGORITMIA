//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53

#include<vector>
#include <iostream>
#include <fstream>
using namespace std;

/*
COSTE Y RECURRENCIA:

Se trata de un algoritmo de divide y vencer�s que se encarga de buscar un elemento en un vector. El coste lo vamos a 
definir sobre el n�mero de elementos de vector n.

        {k0         si n =2
    T(n)
        {T(n/2)+k1  si n>2;

    Luego el coste aplicando el teorema de la divisi�n es logaritmico con respecto al n�mero de elementos del vector 
    T(n) E O(log(n))

*/
void preso_fugado(vector<char> const& v, int c, int f, char p1, char p2, char& resultado) {

    if (c+1== f)
    {
        //Este es el caso en el que preso fugado es el p1.
        if (v[c]!= p1)
        {
            resultado = p1;
        }
        else
        {
            resultado = p2;
        }
    }
    else
    {
        //Tenemos que hacer una b�squeda binaria
        int m = (c + f) / 2;
        char mid = (p1 + p2) / 2;

        if (v[m]<= mid)
        {
            preso_fugado(v, m, f, mid, p2, resultado);
        }
        else
        {
            preso_fugado(v, c, m, p1, mid, resultado);
        }
    }
}

void resuelveCaso() {
 
    char p1, p2;//Siendo p1 el primer preso, y p2 el �ltimo preso.
    char resultado; //Variable en la que devolvemos el resultado.

    cin >> p1 >> p2;

    int n = p2-p1;

    vector<char> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    //Ya que buscamos POSICIONES no ELEMENTOS.
    preso_fugado(v, 0, v.size(), p1, p2, resultado);

    cout << resultado << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}