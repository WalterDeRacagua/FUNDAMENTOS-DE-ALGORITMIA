//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <vector>
#include <iostream>
#include <fstream>
#include <utility>//Seria para utilizar la clase pair.
using namespace std;

//Podemos o bien tener un struct o utilizar pair de la librer�a utility.

struct Participante
{
    string nombre;
    int canicas;
};


void ganador_del_torneo(vector<Participante>const & participantes, int c, int f, Participante& ganador) {

    if (c==f)
    {
        ganador = participantes[c];
    }
    else
    {
        int m = (c + f) / 2;
        Participante ganador1, ganador2;

        ganador_del_torneo(participantes, c, m, ganador1);
        ganador_del_torneo(participantes, m+1, f, ganador2);

        if (ganador1.canicas >= ganador2.canicas)
        {
            ganador = ganador1;
            ganador.canicas += ganador2.canicas / 2;
        }
        else
        {
            ganador = ganador2;
            ganador.canicas += ganador1.canicas / 2;
        }
    }
}


bool resuelveCaso() {

    int n; //Representa el n�mero de participantes del torneo.

    cin >> n;

    if (cin.eof())
        return false;

    vector<Participante> participantes(n);//Vector con los n participantes.
    Participante ganador;

    for (int i = 0; i < n; i++)//Lineal en el n�mero de participantes puesto que dentro del bucle �nicamente se hacen asignaciones de coste constante.
    {
        Participante p;

        cin >> participantes[i].nombre >> participantes[i].canicas;
    }

    ganador_del_torneo(participantes, 0, participantes.size() - 1, ganador);


    cout << ganador.nombre << " " << ganador.canicas << endl;

    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}