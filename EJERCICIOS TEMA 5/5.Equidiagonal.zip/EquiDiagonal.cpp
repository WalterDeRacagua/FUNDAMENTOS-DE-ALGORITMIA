//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


/*
COSTE Y RECURRENCIA DE MI ALGORITMO

Se trata de un algorimto de divide y venceras que divide los n^2 elementos de una matriz
en 4 submatrices mas peque�as para hallar el resultado. Tanto el coste como la recurrencia
las voy a definir sobre N siendo N el n�mero de elementos de la matriz. Tenemos lo siguiente:


        {k0             si N=1;
    T(N)
        {4T(n/4) +k1    si N>1;

Por tanto, aplicando el teorema de la divisi�n de un algoritmo DV con a = 4, b= 4, k=0, tenemos
que a > b^k por tanto el coste del algoritmo T(N) E O(N^(logb(a))) y como a y b son iguales (4),
log 4(4)=1, por tanto el coste T(N) E O(N) que es lineal con respecto al n�mero de elementos de 
la matriz,


*/
void es_equidiagonal(vector<vector<int>> const& matriz, int comienzofilas, int finalfilas, int comienzocolumnas, int finalcolumnas, int& resultado, bool& esEquidiagonal)
{
    if (comienzofilas== finalfilas && comienzocolumnas == finalcolumnas)
    {
        esEquidiagonal = true;
        resultado = matriz[comienzofilas][comienzocolumnas];
    }
    else
    {
        int mitadFilas = (comienzofilas + finalfilas) / 2;
        int mitadColumnas = (comienzocolumnas + finalcolumnas) / 2;

        int resultado1, resultado2, resultado3, resultado4;
        bool esEquidiagonal1, esEquidiagonal2, esEquidiagonal3, esEquidiagonal4;

        es_equidiagonal(matriz, comienzofilas, mitadFilas, comienzocolumnas, mitadColumnas, resultado1, esEquidiagonal1);
        es_equidiagonal(matriz, comienzofilas, mitadFilas, mitadColumnas+1, finalcolumnas, resultado2, esEquidiagonal2);
        es_equidiagonal(matriz, mitadFilas+1, finalfilas, comienzocolumnas, mitadColumnas, resultado3, esEquidiagonal3);
        es_equidiagonal(matriz, mitadFilas+1, finalfilas, mitadColumnas+1, finalcolumnas, resultado4, esEquidiagonal4);

        esEquidiagonal = esEquidiagonal1 && esEquidiagonal2 && esEquidiagonal3 && esEquidiagonal4 && (resultado1 * resultado4 == resultado2 * resultado3);

        resultado = resultado1 * resultado4;
    }
}

void resuelveCaso() {
 
    int n; //Es el n�mero de filas y columnas que tiene nuestra matriz, ya que es cuadrada

    cin >> n;

    vector<vector<int>> matriz(n, vector<int>(n, 0));//Inicializados a 0.

    int resultado;
    bool esEquidiagonal;


    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> matriz[i][j];
        }
    }

    es_equidiagonal(matriz, 0, matriz.size() - 1, 0, matriz.size() - 1, resultado, esEquidiagonal);

    if (esEquidiagonal)
    {
        cout << "SI " << resultado << endl;
    }
    else
    {
        cout << "NO\n";
    }

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}