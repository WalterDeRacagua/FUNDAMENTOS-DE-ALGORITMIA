//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53.

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

/*
COSTE Y RECURRENCIA:

Se trata de un problema de divide y vencer�s, enn el cual tenemos que dividir un vector en mitades
hasta encontrar el m�nimo del mismo. Para ello realizamos dos llamadas para cada mitad del vector y 
comparamos resulados. Tanto el coste como la recurrencia del algoritmo lo voy a definir sobre n, siendo
n el n�mero de elementos del vector:

Recurrencia:

        {k0             si n=1;
    T(n)
        {2T(n/2) +k1    si n >1;

Por tanto, aplicando el teorema de la divisi�n, y teniendo que a =2, b = 2 y k=0, a>b^k ya que 2> 2^0
entonces T(n) E O(n ^(logb (a))). Como log2(2)=1 el coste es lineal en el n�mero de elementos del vector:

Coste:

T(n) E O(n).


*/
void curva_concava(vector<int> const& v, int c, int f, int &resultado) {

    if (c==f)
    {
        resultado = v[c];
    }
    else
    {
        int m = (c + f) / 2;
        int resultado_izquierda, resultado_derecha;

        curva_concava(v, c, m, resultado_izquierda);
        curva_concava(v, m+1, f, resultado_derecha);

        resultado = min(resultado_izquierda, resultado_derecha);
    }



}


bool resuelveCaso() {

    int n,resultado; //Numero de posiciones del vector y el resultado obtenido al llamar a la funci�n

    cin >> n;

    if (cin.eof())
        return false;

    vector<int> v(n);


    for (int i = 0; i < n; i++)//Lineal en n, la lectura y asignaci�n de cada iteraci�n al vector tienen coste constante.
    {
        cin >> v[i];
    }

    curva_concava(v, 0, v.size() - 1, resultado);

    cout << resultado << endl;

    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}