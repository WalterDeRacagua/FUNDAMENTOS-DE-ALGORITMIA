//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;


/*
COSTE Y RECURRENCIA DE MI ALGORITMO.    
   
Se trata de un problema de divide y vencer�s (DV) en el cual 
queremos hacer una b�squeda de un elemento sobre un vector ordenado(b�squeda binaria).
Para definir el coste y la recurrencia lo hacemos sobre el n�mero de elementos que estudiamos
N = f-c.

Recurrencia:

        {k0         si N=1;
    T(N)
        {T(n/2) +k1 si N>1;

Por tanto, aplicando el teorema de la divisi�n, sabiendo que a = 1, b= 2 y k=0, tenemos que 
a = b^k ya que 1 = 2^0 por tanto T(N) E O(N^k* log(N)); como k=0 T(N) E O(log(N))


*/
void numero_a_tachar(vector<int> const& v, int n, int cantado, int c, int f, int& resultado) {

    //Cuando hago b�squedas utilizo c+1 == f, si no utilizo c==f
    if (c+1==f)
    {
        if (v[c] - c == cantado)
        {
            resultado = v[c];
        }
        else
            resultado = -1;
    }
    else
    {
        int m = (c + f) / 2;

        if (v[m]-m > cantado)
        {
            numero_a_tachar(v, n, cantado, c, m, resultado);
        }
        else if (v[m] - m < cantado)
        {
            //Si no fuera b�squeda utilizar�a m+1.
            numero_a_tachar(v, n, cantado, m, f, resultado);
        }
        else
        {
            resultado = v[m];
        }

    }
}


void resuelveCaso() {

    int n, cantado; //Siendo n el n�mero de n�meros del cart�n y c el n�mero cantado
    int resultado; //Variabe en la que se devuelve el resultado

    cin >> n >> cantado;

    vector<int> carton(n);

    for (int i = 0; i < n; i++)
    {
        cin >> carton[i];
    }
    
    //Creo que lo voy a plantear como una b�squeda binaria sobre un vector ordendado.
    //Cuando hago busquedas entonces utilizo v.size() en vez de v.size()-1
    numero_a_tachar(carton, n, cantado, 0, carton.size(), resultado);

    if (resultado == -1)
    {
        cout << "NO\n";
    }
    else
    {
        cout << resultado << endl;
    }



}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}