//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco. E53

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

/*
COSTE Y RECURRENCIA:

Se trata de un algoritmo en el cual aplico divide y vencer�s para llegar a la soluci�n. Para definir
el coste y la recurrencia lo voy a hacer sobre la variable n = f-c+1.

Recurrencia:

        {k0         si n=0;
    T(n)
        {T(n/2)+k1  si n>0;

Por tanto, aplicando el teorema de la divisi�n con a = 1 ya que el n�mero de llamadas recursivas a las 
que se acceden en cada llamada es 1, b = 2 ya que el tama�o de los subproblemas es de la mitad y k=0. Como
a=b^k 1= 2^0 entonces tenemos el siguiente caso:

    Coste T(n) E O(n^k log n). Como k=0(k!=k0 y k!=k1), T(n) E O(log n)
*/
int busqueda_binaria(const vector<int>& v, int c, int f, int first) {

    if (c == f+1)
    {
        return first +c;
    }
    else
    {
        int m = (c + f) / 2;

        int valor_esperado = first + m;

        if (valor_esperado!= v[m])
        {
            return busqueda_binaria(v, c, m - 1, first);
        }
        else
        {
            return busqueda_binaria(v, m + 1, f, first);
        }
      
    }

}


void resuelveCaso() {

    int n, first;//Siendo n el n�mero de elementos restantes del vector y first el primer elemento de la secuencia.

    cin >> n >> first;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

  
    int resultado = busqueda_binaria(v, 0, v.size()-1, first);
    cout << resultado << endl;
    


}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}