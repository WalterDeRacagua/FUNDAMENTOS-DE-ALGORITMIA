//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco. E53

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

/*
COSTE Y RECURRENCIA:

Se trata de un algoritmo de divide y vencer�s para el cual tenemos que conseguir cual
es la m�xima diferencia de dos elementos del vector en posiciones consecutivas. Para definir
el coste y la recurrencia lo voy a hacer sobre n siendo n el n�mnero de elementos de cada partici�n
del vector:
        
        {k0         si n=2;
    T(n)
        {2T(n/2)+k1 si n>2;

Por tanto, como consecuencia de la recurrencia y aplicando el teorema de la divisi�n, como e n�mero de
subproblemas generados es 2, a=2; como el tama�o de cada subproblema es de tama�o la mitad, b=2; y como
el csote de la parte no recursiva del problema es constante, k=0; aplicando el teorema a >b^k 2>2^0
por tanto el coste pertenece a O(n^(log(b)a)) y como a=b log(b)a = 1 por tanto coste E O(n), lineal
en el n�mero de elementos del vector.

*/
void es_picudo(const vector<int>& v, int n, int c, int f, int &max_diferencia) {

    if (f==c+1)
    {
        max_diferencia = v[f] - v[c];
    }
    else
    {
        int m = (c + f) / 2;
        int valorIzquierda, valorDerecha;
        es_picudo(v, n, c, m, valorIzquierda);
        es_picudo(v, n, m, f, valorDerecha);

        max_diferencia = max(valorIzquierda, valorDerecha);
    }
}

void resuelveCaso() {

    int n; //N�mero de elementos del vector
    int max_diferencia = -1111111;
    int valor;

    cin >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    es_picudo(v, n, 0, v.size() - 1, max_diferencia);

    cout << max_diferencia << endl;

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}