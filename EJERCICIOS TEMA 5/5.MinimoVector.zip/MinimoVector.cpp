
// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;


/*
COSTE Y RECURRENCIA DEL ALGORITMO:

Se trata de un algoritmo de divide y vencer�s que trata de buscar el m�nimo en un 
vector desordenado. Voy a definir tanto el coste como la recurrencia sobre N siendo 
esta f-c. Teniendo en cuenta que el caso base es de coste constante, y el caso recursivo 
hace una llamada de coste la mitad y cosas de coste constante, la recurrencia es la siguiente:

        {k0         si N =1
    T(N)
        {T(n/2) +k1 si N>1;

   
Para explicar el coste, como coinsecuencia de la recurrencia y aplicando el teorema de la divisi�n
como a= 1, b= 2 y k=0, como a= b^k 1= 2^0 T(N) = T(log(N))


*/

void minimo_vector(vector<int> const & v,int c, int f, int &resultado) {

    if (c+1== f)
    {
        resultado = v[c];     
    }
    else
    {
        int m = (c + f) / 2;

        if (v[m]< v[c])
        {
            minimo_vector(v, m, f, resultado);
        }
        else
        {
            minimo_vector(v, c, m, resultado);
        }
    }
}


bool resuelveCaso() {

    //Leer caso de prueba: cin>>...

    int n, resultado;//Numero de elementos del vector

    cin >> n;

    if (cin.eof())//Si llega al final del fichero.
        return false;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    minimo_vector(v, 0, v.size(), resultado);

    cout << resultado<<endl;



    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}