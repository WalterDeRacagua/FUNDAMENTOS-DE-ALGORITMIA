// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/*
COSTE Y RECURRENCIA DEL VECTOR:

Se trata de un problema en el cual aplicamos un algoritmo de divide y venceras (DV). Para explicar
el coste y la recurrencia del algoritmo lo voy a hacer sobre la variable n, siendo n.

Recurrencia:

        {k0             si n=1;
    T(n)
        {2T(n/2) +k1    si n >1;

Coste:

Partiendo de la recurrencia, sabemos que el n�mero de subproblemas en el que dividimos el problema original es 2,
luego a =2, el tama�o de estos subproblemas es de la mitad al original, luego b = 2, y el coste del resto de operaciones
que se realizan dentro del algoritmo es constante, luego k=0 (siendo k != k1 && k0). Por tanto, aplicando el teorema de 
la divisi�n, a > b^k ya que 2>2^0, luego el coste pertence a O(n^log(b)a); como a =b log(b)a =1 y por tanto el coste del 
algoritmo E O(n^1)= O(n), lo cual es lineal en el n�mero de elementos del vector.

*/
void es_caucasico(const vector<int>& v, int c, int f, bool& esCaucasico, int& numPares) {

    if (c==f)
    {
        if (v[c]%2==0)
        {
            numPares = 1;
        }
        else
        {
            numPares = 0;
        }
        esCaucasico = true;
    }
    else
    {
        int m = (c + f) / 2;
        bool es_caucasico_izquierda, es_caucasico_derecha;
        int num_pares_izquierda, num_pares_derecha;
        es_caucasico(v, c, m, es_caucasico_izquierda, num_pares_izquierda);
        es_caucasico(v, m+1, f, es_caucasico_derecha, num_pares_derecha);

        esCaucasico = es_caucasico_izquierda && es_caucasico_derecha && abs(num_pares_izquierda - num_pares_derecha) <= 2;
        numPares = num_pares_izquierda + num_pares_derecha;
    }


}


bool resuelveCaso() {

    int n;//n es el n�mero de elementos del vector.
    int numPares; //Almacena el numero de pares del vector, nos sirve para saber si es caucasico.

    cin >> n;

    if (n ==0)
        return false;

    vector<int> v(n);//Vecto de n enteros que tenemos que leer...

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    bool esCaucasico;

    es_caucasico(v, 0, v.size()-1, esCaucasico, numPares);

    if (esCaucasico)
    {
        cout << "SI\n";
    }
    else
    {
        cout << "NO\n";
    }

    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}