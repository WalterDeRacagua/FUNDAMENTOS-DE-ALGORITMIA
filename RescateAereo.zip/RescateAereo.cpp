//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <vector>
#include <iostream>
#include <fstream>
#include <utility>
using namespace std;

//Precondici�n:{0<= n < v.size() && t>0}
pair<int, int> secuencia_mas_larga(vector<int> v, int t, int n) {
    int s = -1; // Inicio de la secuencia actual
    int r = 0;  // Longitud de la secuencia m�s larga encontrada
    pair<int, int> comienzo_fin = { -1, -1 }; // Indices del comienzo y fin de la secuencia m�s larga

    int longitud_actual = 0;
    //Funci�n de cota: n-i
    //En cuanto al coste es lineal con respecto a n, ya que dentro del bucle �nicamente hacemos asignaciones de coste constante. Por tanto coste E O(n)
    for (int i = 0; i < n; i++) {
        //Invariante: o<=i< v.size() ^ 0<=s < v.size() ^ r ={max p,q: p <=i <=q: v[i]<t: q-p} comienzo_fin = {max i, j: i<=j < v.size():v[i}<t}

        if (v[i] > t) {
            if (longitud_actual == 0) {
                s = i;
            }
            longitud_actual++;
            if (longitud_actual > r) {
                r = longitud_actual;
                comienzo_fin = { s, i };
            }
        }
        else {
            longitud_actual = 0;
        }
    }

    return comienzo_fin;
}
//Postcondici�n:{comienzo_fin = {max i, j: i<=j < v.size():v[i}<t}

void resuelveCaso() {
 
    int n, t;// Siendo n el n�mero de edificios y la t la altura del transporte.

    cin >> n >> t;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }


    pair<int, int> comienzo_fin = secuencia_mas_larga(v, t, n);

    cout << comienzo_fin.first << " " << comienzo_fin.second << endl;


}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}