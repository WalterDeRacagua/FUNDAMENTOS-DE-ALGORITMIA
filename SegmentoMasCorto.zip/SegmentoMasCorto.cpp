
// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco e53 

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

//Precondici�n: {0<=n<=v.size(), k >0}
int tramo_minimo(vector<bool> const& v, int n, int k) {
    int segmento_corto = n + 1;
    int num_trues = 0;
    int inicio = 0;

    //Coste: lineal con respecto al n�mero de elementos del bucle.
    //Funci�n de cota: n-fin
    for (int fin = 0; fin < n; ++fin) {
        //Invariante: 0<= fin < n ^ 0<=inicio<n ^ num_trues ={#i: o<=i< v.size(): v[i] =true} ^ segmento_corto{min p,q: 0<=p<q: {#i: p<=i<q: v[i]=true}= k: q-p}


        if (v[fin]) {
            ++num_trues;
        }

        while (num_trues == k) {
            segmento_corto = min(segmento_corto, fin - inicio + 1);
            if (v[inicio]) {
                --num_trues;
            }
            ++inicio;
        }
    }

    return  segmento_corto;
}
//int tramo_largo(vector<bool> const& v, int n, int k) {
//    int segmento_largo = 0;
//    int num_trues = 0;
//    int inicio = 0;
//
//    for (int fin = 0; fin < n; ++fin) {
//
//
//        if (v[fin]) {
//            ++num_trues;
//        }
//
//        if (num_trues == k)
//        {
//            segmento_largo = max(segmento_largo, fin - inicio + 1);
//        }
//        else if (num_trues >k)
//        {
//            while (num_trues> k)
//            {
//                if (v[inicio])
//                {
//                    --num_trues;
//                }
//                ++inicio;
//            }
//        }
//       
//    }
//
//    return  segmento_largo;
//}


bool resuelveCaso() {

    int n, k;

    cin >> n;

    if (n==-1)
        return false;

    vector<bool> v(n);

    int aux;

    for (int i = 0; i < n; i++)
    {
        cin >> aux;
        if (aux ==0)
        {
            v[i] = false;
        }
        else
        {
            v[i] = true;
        }
    }

    cin >> k;

    int segmento_corto = tramo_minimo(v, n, k);
    //int segmento_largo = tramo_largo(v, n, k);

    cout << segmento_corto << endl;
    cout << segmento_largo << endl;
    cout << endl;

    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}