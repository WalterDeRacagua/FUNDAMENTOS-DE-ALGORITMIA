
// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

bool ruta_apta(vector<int> v, int D, int N) {

    int minimum = v[0];

    for (int i = 1; i < v.size(); i++)
    {
        if (v[i] > v[i - 1])
        {
            if (v[i] - minimum > D)
            {
                return false;
            }
        }
        else if (v[i] <= v[i - 1])
        {
            minimum = v[i];
        }
    }

    return true;
}


bool resuelveCaso() {

    //Leer caso de prueba: cin>>...

    int D, N; //Siendo D el desnivel y N el n�mero de cotas.

    cin >> D >> N;

    if (cin.eof())
        return false;

    vector<int> v(N);

    for (int i = 0; i < N; i++)
    {
        cin >> v[i];
    }

    bool b = ruta_apta(v, D, N);

    if (b)
    {
        cout << "APTA\n";
    }
    else
    {
        cout << "NO APTA\n";
    }


    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}