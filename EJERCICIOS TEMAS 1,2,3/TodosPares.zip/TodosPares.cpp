//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


//a) todosPares(v,p,q) ={forAll i: p<=i< q: v[i]%2=0}

//Precondici�n: {0<=n< v.size()}
int numero_segmentos_de_pares(vector<int> v, int n) {

    int pares_seguidos = 0;
    int numero_segmentos = 0;

    //Funci�n de cota = v.size() - i ya que decrece en cada iteraci�n.
    //Coste es lineal con respecto al n�mero de elementos del vector v, ya que recorremos los elementos en el bucle for una sola vez y dentro
    //del bucle se hacen operaciones de costen constante como asignaciones y comprobaciones, luego es del orden O(v.size()). 
    for (int i = 0; i < v.size(); i++)
    {
        //Invariante: 0<= i <v.size() ^ pares_seguidos = {#i: 0<=i< v.size(): v[i] %2=0^{forAll j: 0<=j<=i: v[j]%2=0}}
        if (v[i]%2==0)
        {
            pares_seguidos++;
        }
        else
        {
            pares_seguidos = 0;
        }

        numero_segmentos += pares_seguidos;
    }


    return numero_segmentos;
}
//Postcondici�n: {numero_segmentos ={#p,q: 0<=p<q< v.size(): todosPares(v,p,q)}}

void resuelveCaso() {
    
    int n;//N�mero de elementos del vector

    cin >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    int num_segmentos = numero_segmentos_de_pares(v, n);

    cout << num_segmentos << endl;

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}