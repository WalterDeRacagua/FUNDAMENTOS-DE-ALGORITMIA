//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco. E53 

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


bool bien_dividido(vector<int> v, int n, int p) {

    int maximo = v[0];

    // Recorrer la primera parte del vector hasta la posici�n p
    for (int i = 1; i <= p; ++i) {
        maximo = max(maximo, v[i]);
    }

    // Recorrer la segunda parte del vector desde la posici�n p+1 hasta el final
    for (int i = p + 1; i < v.size(); ++i) {
        if (v[i] <= maximo) {
            return false;
        }
    }

    return true;

}


void resuelveCaso() {
   
    int n, p;//Siendo n el n�mero de elementos del vector.

    cin >> n >> p;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    bool dividido = bien_dividido(v, n, p);

    if (dividido)
    {
        cout << "SI\n";
    }
    else
    {
        cout << "NO\n";
    }
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}