// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

int mas_positivas_izquierda_que_derecha(vector<int> v, int n, int k) {

    int mitad = k / 2;
    int positivos_izquierda = 0;
    int positivos_derecha = 0;
    int tamanyo_actual = 0;
    int segmentos = 0;

    for (int i = 0; i < n; i++)
    {
        tamanyo_actual++;

        if (tamanyo_actual <= mitad)
        {
            if (v[i] > 0)
            {
                positivos_izquierda++;
            }
        }
        else if (tamanyo_actual >= mitad && tamanyo_actual <= k)
        {
            if (v[i] > 0)
            {
                positivos_derecha++;
            }
        }
        if (tamanyo_actual == k)
        {
            if (positivos_izquierda >= positivos_derecha)
            {
                segmentos++;
            }
            if (v[i - k + 1] > 0)
            {
                positivos_izquierda--;
            }
            if (v[i - mitad + 1] > 0)
            {
                positivos_derecha--;
                positivos_izquierda++;
            }
            tamanyo_actual--;
        }

    }

    return segmentos;
}

bool resuelveCaso() {

    //Leer caso de prueba: cin>>...
    int n, k; //Donde n es el n�mero de elementos del vector y k es la longitud del vector  

    cin >> n >> k;

    if (n == 0)
        return false;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }


    int num_segmentos = mas_positivas_izquierda_que_derecha(v, n, k);

    cout << num_segmentos << endl;


    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}