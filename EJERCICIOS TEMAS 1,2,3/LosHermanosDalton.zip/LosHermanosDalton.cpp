
// NOMBRE Y APELLIDOS Sergio S�nchez Carrasco. 

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

//PRE:{0< n<= v.size()}
bool son_dalton(vector<int> alturas_dalton, int n) { //proc son_dalton(in vector<int> alturas_dalton, in int n) dev bool b. 

    bool b = true;

    //Funci�n de cota en ambos casos = n-i
    //Invariante: 1< i < n ^ b ={p.t i: 0<i<n: v[i-1]<v[i]} or b= {p.t i: o<i< n: v[i-1]> v[i]}
    if (alturas_dalton[0]< alturas_dalton[1])
    {

        int i = 2;

        while (i< n && b)
        {
            if (alturas_dalton[i - 1] >= alturas_dalton[i])
            {
                b = false;
            }
            i++;
        }
    }
    else if (alturas_dalton[0]> alturas_dalton[1])
    {
        int i = 2;

        while (i < n && b)
        {
            if (alturas_dalton[i - 1] <= alturas_dalton[i])
            {
                b = false;
            }
            i++;
        }
    }
    else
    {
        return false;
    }
    
    return b;
}
//POS:b ={p.t i: 0<i<n: v[i-1]<v[i]} or b= {p.t i: o<i< n: v[i-1]> v[i]}


//
bool resuelveCaso() {

    //Leer caso de prueba: cin>>...
    int n; //Representa el numero de Dalton

    cin >> n;

    if (n==0)
        return false;

    vector<int> alturas_daltons(n);

    for (int i = 0; i < n; i++)//Lineal en el n�mero de daltons por tanto.
    {
        cin >> alturas_daltons[i];//O(1) es una simple asignaci�n
    }

    bool b = son_dalton(alturas_daltons, n);

    if (b)
    {
        cout << "DALTON\n";
    }
    else
    {
        cout <<"DESCONOCIDOS\n";
    }

    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}