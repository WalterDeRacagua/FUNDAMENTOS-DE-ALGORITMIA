
// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco. E53 

#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

//PREC{0<= anyos < v.size() && nacionalidad == string}
int anyos_pasados_desde_victoria(vector<string> v, int anyos, string nacionalidad) {// func(in vector<int>v, in int anyos, in string nacionalidad) dev int contador

    bool encontrado = false;
    int i = v.size() - 1;
    int contador=1;

    while (i >=0&& !encontrado)//Funci�n de cota = v.size()-1
    {
        //Invariante:contador ={# i: 0<=i< v.size(): v[i]!= nacionalidad} encontrado = {E i: 0<=i< v.size(): v[i]== nacionalidad} donde E = existe.

        if (v[i]== nacionalidad)
        {
            encontrado= true;
            return contador;
        }

        contador++;
        i--;
    }
    //Coste lineal con respecto al n�mero de elementos del vector en el peor de los casos.

    return -1;
}
//POST: contador ={# i: 0<=i< v.size(): v[i]!= nacionalidad} encontrado = {E i: 0<=i< v.size(): v[i]== nacionalidad} donde E = existe.


bool resuelveCaso() {

    //Leer caso de prueba: cin>>...

    int anyos;
    string nacionalidad;

    cin >> anyos >> nacionalidad;

    if (anyos ==0)
        return false;

    vector<string> v(anyos);

    for (int i = 0; i < anyos; i++)
    {
        cin >> v[i];
    }

    int anyos_pasados = anyos_pasados_desde_victoria(v, anyos, nacionalidad);

    if (anyos_pasados==-1)
    {
        cout << "NUNCA\n";
    }
    else
    {
        cout << anyos_pasados << endl;
    }
    //Resolver problema
    //Escribir resultado
    return true;
}


int main() {

    // ajuste para que cin extraiga directamente de un fichero
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    while (resuelveCaso());

    // restablecimiento de cin
#ifndef DOMJUDGE
    std::cin.rdbuf(cinbuf);
    system("pause");
#endif
    return 0;
}