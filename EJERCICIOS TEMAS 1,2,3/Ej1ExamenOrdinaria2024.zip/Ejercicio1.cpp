//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


//1)todosIguales(v,p,q): {bool b= {p.t i: p<= i< q: v[i]==v[i+1]}} donde p.t = para todo


//Precondici�n: {0< n <= v.size() ^ 1<=l<= n}
int num_segmentos(vector<int> v, int l, int n) {
    int segmentos = 0;
    int actual = -1; 
    int longitud_actual = 0;

    //Funci�n de cota: n-i, ya que decrece en cada iteraci�n del bucle y al salir se hace 0.
    //Coste: Bucle que recorre todos los elementos del vector, y dentro del vector �nicamente se realizan
    //asignaciones y comprobaciones de coste constante. Luego el coste del algoritmo pertenece al O(n), siendo
    //n el n�mero de elementos del vector.
    for (int i = 0; i < n; i++) {
        //Invariante: 0<=i< v.size()^actual= {i: 0<= i < v.size(): v[i]}^longitud_actual={p,q: 0<=p<q<v.size(): todosIguales(v,p,q): q-p}^segmentos = {#p,q: 0<=p<q<v.size(): (q-p+1 <=l)^todosIguales(v,p,q)};
        if (longitud_actual == 0 || v[i] == actual) {
            actual = v[i];
            longitud_actual++;
        }
        else {
            actual = v[i];
            longitud_actual = 1;
        }

        if (longitud_actual >= l) {
            segmentos += (longitud_actual - l) + 1;
        }
    }

    return segmentos;
}
//Postcondici�n: segmentos = {#p,q: 0<=p<q<v.size(): (q-p+1<=l)^todosIguales(v,p,q)};


void resuelveCaso() {
    
    int l,  n; //Longitud minima del vector, tama�o del vector.

    cin >> l >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }


    int segmentos= num_segmentos(v, l, n);

    cout << segmentos << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}