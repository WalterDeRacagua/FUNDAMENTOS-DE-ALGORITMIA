//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco E53 


#include <vector>
#include <iostream>
#include <fstream>
using namespace std;


int segmento_consecutivos(vector<int> v, int n) {

    if (n ==0)
    {
        return 0;
    }

    int s = 0;
    int r = 1;

    for (int i = 1; i < n; i++)
    {
        if (abs(v[i]-v[i-1])!= 1)//Esto es que sean consecutivos
        {
            s = i;
        }

        r = max(r, i - s + 1);
    }

    return r;
}


void resuelveCaso() {
  
    int n; //Siendo n la longitud o el n�mero de elementos del vector.

    cin >> n;

    vector<int> v(n);//Vector de n posiciones.

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    int segmento = segmento_consecutivos(v, n);

    cout << segmento << endl;



}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}