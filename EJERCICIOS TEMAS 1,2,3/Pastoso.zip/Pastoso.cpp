//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco


#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

//Precondici�n: {0<= n< v.size()}
int indice_pastoso(vector<int> v, int n) {// func indice_pastoso(in vector<int> v, in int n) dev int p

    int suma = 0;

    //Coste en el peor de los casos es lineal con respecto al n�mero de elementos del vector. O(n)
    for (int i = v.size()-1; i >=0 ; i--)//Funci�n de cota v.size() ya que decrece en cada iteraci�n
    {
        //Invariante del bucle:  p ={max i: 0<=i< v.size(): v[i]== suma(i,v.size())}
        //Donde suma(int c, int f) = {sum j: i <=j < v.size():v[j]}
        if (v[i]== suma)
        {
            return i;
        }
        else
        {
            suma += v[i];
        }
    }

    return -1;
}
//Postcondici�n = p ={max i: 0<=i< v.size(): v[i]== suma(i,v.size())}
//Donde suma(int c, int f) = {sum j: i <=j < v.size():v[j]}

void resuelveCaso() {

    int n; //n es el n�mero de elementos que tendr� el vector

    cin >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    //Tendremos que recorrer este vector pero desde el final, de forma quee devolvemos el primer pastoso en vez de el �ltimo
    int pastoso = indice_pastoso(v, n);

    if (pastoso == -1)
    {
        cout << "No\n";
    }
    else
        cout << "Si " << pastoso << endl;

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}