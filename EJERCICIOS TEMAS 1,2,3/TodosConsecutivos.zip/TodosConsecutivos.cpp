//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

//1)todosConsecutivos(v,p,q) = {bool b = {p.t i: p<=i< q: abs(v[i}-v[i+1])==1}

//Precondici�n: 0<= n <= v.size()
long long int num_segmentos_consecutivos(const vector<long long int>& v, int n) {

    long long int segmento_actual = 0;
    long long int segmentos_consecutivos = 0;

    //Funci�n de cota: n-i+-1
    //Coste: Es un bucle que se ejecuta n veces y dentro del bucle se realizan asignaciones y condicionales 
    // de coste constante, luego el coste general del bucle y por tanto del algoritmo es del orden exacto de n.
    //O(n) lineal en el n�mero de elementos del vector.
    for (int i = 1; i < n; i++)
    {
        //Entonces ambos son consecutivos
        if (abs(v[i-1]- v[i])==1)
        {
            segmento_actual++;
        }
        else
        {
            segmento_actual = 0;
        }

        segmentos_consecutivos += segmento_actual;
    }

    return segmentos_consecutivos;
}
//Postcondici�n: segmentos_consecutivos = {#p,q: 0<= p < q <v.size(): todosConsecutivos(v,p,q)}


void resuelveCaso() {
  
    int n; //numero de elementos del vector que vamos a leer.

    cin >> n;

    vector<long long int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    long long int num_segmentos= num_segmentos_consecutivos(v, n);

    cout << num_segmentos << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}