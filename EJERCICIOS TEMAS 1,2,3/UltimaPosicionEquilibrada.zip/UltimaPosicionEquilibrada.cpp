//NOMBRE y APELLIDOS: Sergio S�nchez Carrasco. E53


#include <iostream>
#include <vector>
#include <fstream>
#include <utility>//Si necesitaramos un pair.
using namespace std;


//Prec: {true}, es decir, para cualquier entrada
int ultimo_equilibrio(vector<int> v, int n) {

    int p = -1;
    int numUnos = 0;
    int numCeros = 0;

    //Este bucle tiene coste lineal en el n�mero de elementos que tiene el bucle, puesto que dentro del mismo �nicamente hacemos asginaciones
    //y comprobaciones de coste constante. 
    for (int i = 0; i < n; i++)//Funci�n de cota: n-i
    {   
        //Invariante del Bucle: 0<=i< v.size() ^ p ={max i: 0<=i< v.size(): numCeros(v, i)== numUnos(v,i)}
        //donde numUnos(v, j) = #i : 0<= i < j : v[i] = 1 y numCeros(v, j) = #i : 0<= i < j : v[i] = 0.
        if (v[i]==0)
        {
            numCeros++;
        }
        else if (v[i]==1)
        {
            numUnos++;
        }
        if (numCeros == numUnos)
        {
            p = i;
        }
    }
    if (numCeros == numUnos)
    {
        p = v.size() - 1;
    }

    return p;
}
//Post : {-1<=p < v.size() ^ numUnos(v,p+1)= numCeros(v,p+1) ^ p.t k :p <k <vsize() : numUnos(v,k +1)= numCeros(v,k+1)}
// donde numUnos(v, j) = #i : 0<= i < j : v[i] = 1 y numCeros(v, j) = #i : 0<= i < j : v[i] = 0.

void resuelveCaso() {
  
    int n; //Es el n�mero de posiciones que tiene el vector.

    cin >> n;

    vector<int> v(n);

    for (int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    int p = ultimo_equilibrio(v, n);

    cout << p << endl;

}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}