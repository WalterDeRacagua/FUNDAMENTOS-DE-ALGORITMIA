//NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco E53 

#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

//a) todosPares(v,p,q) ={p.t i: p<=i < q: v[i] %2=0}

//b) noMas(v,p,q,k) = {p.t i: p<=i<q: todosPares{v,p,q}.lenght()< k}

//Precondici�n: {0<=n< v.size() ^ k>=0}
int longitud_mas_larga(vector<int>& v, int n, int k) {

    int actual = 0,mayor =0, pares=0;

    //Coste: Lineal con respecto al n�mero de elementos del vector, O(n)
    //Funci�n de cota: n-i
    for (int i = 0; i < n; i++)
    {
        //donde p.t = para todo.
        //Invariante del bucle: 0<=i< v.size() ^ pares = (#i: 0<=i< v.size(): v[i]%2 =0 ^ (p.t k: 0<= k <=i: v[k] %2 =0)) ^mayor = {max p,q: p<=i< q: noMas(v,p,q,k): q-p} ^ 0<=actual<= n
        if (v[i]%2==0)//Si es par  
        {
            pares++;

            if (pares > k)
            {
                if (v[i-k]%2==0)
                {
                    pares--;
                    actual = k;
                }
            }
            else
            {
                actual++;
            }
        }
        else
        {
            pares = 0;
            actual++;
        }
        mayor = max(mayor,actual);
    }

    return mayor;
}
//Postcondici�n: mayor = {max p,q: p<=i< q: noMas(v,p,q,k): q-p}

void resuelveCaso() {
    int n, k; // n: n�mero de elementos, k: n�mero m�ximo de pares consecutivos permitidos
    cin >> n >> k;

    vector<int> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i];
    }

    int segmento_mas_largo = longitud_mas_larga(v, n, k);
    cout << segmento_mas_largo << endl;
}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif

    unsigned int numCasos;
    cin >> numCasos;
    // Resolvemos cada caso
    for (unsigned int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }

#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}
