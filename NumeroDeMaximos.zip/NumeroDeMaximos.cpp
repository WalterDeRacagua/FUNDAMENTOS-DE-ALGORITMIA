
// NOMBRE Y APELLIDOS: Sergio S�nchez Carrasco. E53 

#include <iostream>
#include <vector>
#include <fstream>
#include <utility>
using namespace std;

//PRE:{O< n< puntuacion.size()}
pair<int, int> puntuacion_maximo_veces(vector<int> puntuacion) {// func puntuacion_maximo_veces(in vector<int> puntuacion) dev pair<int,int> <mayor,veces>

    int maximo = puntuacion[0];
    int veces = 1;

    for (int i = 1; i < puntuacion.size(); i++)//Funci�n de cota = v.size()-i
    {
        //Invariante: 0<i<v.size() ^ maximo = {max i: 0< i< v.size(): v[i]} ^ veces{#i: 0<i<v.size(): v[i]==maximo}
        if (puntuacion[i]> maximo)
        {
            maximo = puntuacion[i];
            veces = 1;
        }
        else if (puntuacion[i]== maximo)
        {
            veces++;
        }
    }
    
    //Coste: Es lineal con respecto al n�mero de elementos que tiene el vector puesto que dentro del bucle �nicamente se hacen operaciones 
    //de coste constante (asignaciones comprobaciones...) Luego coste E O(puntuacion.size()).



    return { maximo,veces };
}
//POST:{maximo = {max i: 0< i< v.size(): v[i]} ^ veces{#i: 0<i<v.size(): v[i]==maximo}}

void resuelveCaso() {
   
    vector<int> puntuacion;

    int num;

    cin >> num;

    int i = 0;

    while (num!=0)
    {
        puntuacion.push_back(num);//O(1)
        cin >> num;
        i++;
    }

    auto [maximo, num_veces] = puntuacion_maximo_veces(puntuacion);

    cout << maximo << " " << num_veces << endl;



}

int main() {
    // Para la entrada por fichero.
#ifndef DOMJUDGE
    std::ifstream in("casos.txt");
    auto cinbuf = std::cin.rdbuf(in.rdbuf());
#endif


    unsigned int numCasos;
    std::cin >> numCasos;
    // Resolvemos
    for (int i = 0; i < numCasos; ++i) {
        resuelveCaso();
    }


#ifndef DOMJUDGE // para dejar todo como estaba al principio
    std::cin.rdbuf(cinbuf);
    system("PAUSE");
#endif

    return 0;
}